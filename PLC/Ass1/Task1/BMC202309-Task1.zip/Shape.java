public abstract class Shape {
    public abstract double sizeOf();
    public abstract boolean equals(Object o);
    public abstract String toString();
}
