public abstract class Shape implements Sortable {
    public abstract double sizeOf();
    public abstract boolean equals(Object o);
    public abstract String toString();
}
